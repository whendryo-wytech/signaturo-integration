insert into usu_tsgn000eaf
select a.numemp,a.codfil,'b8b6a402-7c14-11ee-b962-0242ac120002'
from r030fil a
where 1=1
  and a.numemp = 1
;